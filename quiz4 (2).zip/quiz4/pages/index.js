import Head from 'next/head'
import Image from 'next/image'
import styles from '../styles/Home.module.css'

export default function Home() {


  function Bunny(name, movies, balance, debt, primeNum, bunnies=[]) {
    return {
      name,
      movies,
      balance,
      debt,
      primeNum,
      bunnies
    }
  }

  function print(b, spaces = 0) {
    let str = ' ';
    
    let total = b.balance - b.debt;

    for(let i = 0; i < spaces; i++) {
      str += ' ';
    }
  
    str += `Name is ${b.name} and i have a total balance of ${total}, with favourite movies of ${b.movies}` ;
    return str;
  }

  function printAll(b, spaces = 0) {

    var primeNumList = [];
    let mode = 0;
    let median = 0;
    let range = 0;
    var str = print(b, spaces);
   
    
    for(const child of b.bunnies) {
      str += printAll(child, spaces += 4) + "\n\n";
      // add total prime num
      primeNumList.push(child.primeNum);
    }

    
    for(var i = 0; i < primeNumList.length; i++) {
      median += primeNumList[i];
    }
    // calculate mode, median and range
    range = primeNumList[primeNumList.length-1] - primeNumList[0];
    median /= primeNumList.length;
    mode = primeNumList[primeNumList.length/2];

    

    //console.log('Range: ' + range + "\nMedian: " + median + "\n Mode: " + mode);
    return str + 'Range: ' + range + "\nMedian: " + median + "\n Mode: " + mode;
  }

  /*
function conjuncture(b, stepsCount) {
    let num = 7;
    var steps = stepsCount;

    if(num % 2 == 0) {
      // then its even
      num = num / 2;
      steps++;
      if(num == 1) {
        return steps;
      }
        conjuncture(num, steps);
      
    } else {
      num = (num * 3) + 1
      if(num == 1) {
        return steps;
      }
        conjuncture(num, steps);
     
    }
    
  }
  */

  function addChild(b, c) {
    b.bunnies.push(c);
  }

  const bunny1 = Bunny("Seira", "King Kong, End of an Eiras", 5912323, 2323, 2);
  const bunny2 = Bunny("Leira", "Return of the kings", 5913, 23, 5);
  const bunny3 = Bunny("Meira", "King Meiras the 5th", 591445, 29, 7);


  addChild(bunny1, bunny2);
  addChild(bunny1, bunny3);

  printAll(bunny1);
  
  //console.log('The amount of steps were ' + conjuncture(bunny1.bunnies, 0));

  return (
    <div className={styles.container}>
      {printAll(bunny1)}
    </div>
  )
}
